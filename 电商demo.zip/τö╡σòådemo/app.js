App({
  onLaunch: function () {
    this.checkLogin(this.sendSessionKey, this.login);
  },
  getAppData: function(){
    wx.request({
      url: '/index.php?r=AppData/detail',
      data: {
        app_id: this.globalData.appId
      },
      header: {
        'Content-Type': 'application/json'
      },
      success: function(res) {
        if (res.status !== 0) { return; }
        var that = this,
            info = res.data;

        this.globalData.formData = info.form_data;
      }
    });
  },


  /**
   * 微信接口封装
   */

  sendRequest: function(param, customSiteUrl){
    var data = param.data || {},
        header = param.header,
        requestUrl;

    data._app_id = this.getAppId();
    data.app_id = this.getAppId();

    if(customSiteUrl) {
      requestUrl = customSiteUrl + param.url;
    } else {
      requestUrl = this.globalData.siteBaseUrl + param.url;
    }

    if(param.method && param.method.toLowerCase() == 'post'){
      data = this.modifyPostParam(data);
      header = header || {
        'Content-Type': 'application/x-www-form-urlencoded;'
      };
    }

    wx.request({
      url: requestUrl,
      data: data,
      method: param.method || 'GET',
      header: header || {
        'Content-Type': 'application/json'
      },
      success: function(res) {
        if (res !== undefined) {
          typeof param.success == 'function' && param.success(res.data);
        }
      },
      fail: function(res){
        typeof param.fail == 'function' && param.fail(res.data);
      },
      complete: function(res){
        typeof param.complete == 'function' && param.complete(res.data);
      }
    });
  },
  turnToPage: function(url, isRedirect){
    if(!isRedirect){
      wx.navigateTo({
        url: url
      });
    } else {
      wx.redirectTo({
        url: url
      });
    }
  },
  turnBack: function(){
    wx.navigateBack();
  },
  setPageTitle: function(title){
    wx.setNavigationBarTitle({
      title: title
    });
  },
  showToast: function(param){
    wx.showToast({
      title: param.title,
      icon: param.icon,
      duration: param.duration || 2000,
      success: function(res){
        console.log('success');
        typeof param.success == 'function' && param.success(res);
      },
      fail: function(res){
        typeof param.fail == 'function' && param.fail(res);
      },
      complete: function(res){
        typeof param.complete == 'function' && param.complete(res);
      }
    })
  },
  hideToast: function(){
    wx.hideToast();
  },
  showModal: function(param){
    wx.showModal({
      title: param.title || '提示',
      content: param.content,
      showCancel: param.showCancel || false,
      cancelText: param.cancelText || '取消',
      cancelColor: param.cancelColor || '#000000',
      confirmText: param.confirmText || '确定',
      confirmColor: param.confirmColor || '#3CC51F',
      success: function(res) {
        if (res.confirm) {
          typeof param.confirm == 'function' && param.confirm(res);
        } else {
          typeof param.cancel == 'function' && param.cancel(res);
        }
      },
      fail: function(res){
        typeof param.fail == 'function' && param.fail(res);
      },
      complete: function(res){
        typeof param.complete == 'function' && param.complete(res);
      }
    })
  },
  chooseImage: function(callback, count){
    wx.chooseImage({
      count: count || 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        var tempFilePaths = res.tempFilePaths
        typeof callback == 'function' && callback(tempFilePaths);
      }
    })
  },
  previewImage: function(previewUrl, previewUrlsArray){
    wx.previewImage({
      current: previewUrl,
      urls: previewUrlsArray
    })
  },
  uploadImage: function(filePath, callback){
    this.sendRequest({
      url: '/index.php?r=AppData/uploadImg',
      data: {
        filePath: filePath
      },
      method: 'POST',
      success: callback
    });
  },
  playVoice: function(filePath){
    wx.playVoice({
      filePath: filePath
    });
  },
  pauseVoice: function(){
    wx.pauseVoice();
  },
  wxPay: function(param){
    wx.requestPayment({
      'timeStamp': '',
      'nonceStr': '',
      'package': '',
      'signType': 'MD5',
      'paySign': '',
      success: function(res){
      },
      fail: function(res){
      }
    })
  },
  makePhoneCall: function(number, callback){
    if(number.currentTarget){
      var dataset = number.currentTarget.dataset;

      number = dataset.number;
    }
    wx.makePhoneCall({
      phoneNumber: number,
      success: callback
    })
  },
  login: function(){
    var that = this;

    wx.login({
      success: function(res){
        if (res.code) {
          that.sendCode(res.code);

        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    })
  },
  sendCode: function(code){
    var that = this;
    this.sendRequest({
      url: '/index.php?r=AppUser/onLogin',
      data: {
        code: code
      },
      success: function(res){
        if(res.status == 0){
          that.getUserWxInfo();
          wx.setStorage({
            key: 'session_key',
            data: res.data
          });
        }
      }
    })
  },
  sendSessionKey: function(){
    var that = this;
    try {
      var key = wx.getStorageSync('session_key');
      this.sendRequest({
        url: '/index.php?r=AppUser/onLogin',
        data: {
          session_key: key
        },
        success: function(res){
          if(res.status == 0){
            that.getUserInfo();
          } else {
            that.getUserWxInfo();
          }
        }
      })

    } catch(e) {

    }
  },
  getUserInfo: function(){
    var that = this;
    this.sendRequest({
      url: '/index.php?r=AppData/getXcxUserInfo',
      success: function(res){
        if(res.status == 0){
          if(res.data){
            that.globalData.userInfo = res.data;

          } else {
            that.getUserWxInfo();
          }
        }
      }
    })
  },
  getUserWxInfo: function(){
    var that = this;
    wx.getUserInfo({
      success: function(res){
        that.sendUserInfo(res.userInfo);
      }
    })
  },
  sendUserInfo: function(userInfo){
    var that = this;
    this.sendRequest({
      url: '/index.php?r=AppUser/LoginUser',
      method: 'post',
      data: {
        userInfo: userInfo
      },
      success: function(res){
        if(res.status == 0){
          that.globalData.userInfo = res.userInfo;
        }
      }
    })
  },
  checkLogin: function(success, fail){
    var that = this;
    wx.checkSession({
      success: function(){
        //登录态未过期
        success();
      },
      fail: function(){
        //登录态过期
        fail();
      }
    })
  },



  /**
   * app业务逻辑方法
   */
  getDynamicPageData: function(param){
    param.url = '/index.php?r=AppData/getFormData';
    this.sendRequest(param);
  },
  getDynamicListData: function(param){
    param.url = '/index.php?r=AppData/getFormDataList';
    this.sendRequest(param);
  },
  getAssessList: function(param){
    param.url = '/index.php?r=AppShop/GetAssessList';
    this.sendRequest(param);
  },
  getOrderDetail: function(param){
    param.url = '/index.php?r=AppShop/getOrder';
    this.sendRequest(param);
  },
  clickLike: function(param){
    param.url = '/index.php?r=AppData/addCount';
    this.sendRequest(param);
  },
  clickCancelLike: function(param){
    param.url = '/index.php?r=AppData/delCount';
    this.sendRequest(param);
  },
  modifyPostParam: function(obj) {
    let query = '',
        name, value, fullSubName, subName, subValue, innerObj, i;

    for(name in obj) {
      value = obj[name];

      if(value instanceof Array) {
        for(i=0; i < value.length; ++i) {
          subValue = value[i];
          fullSubName = name + '[' + i + ']';
          innerObj = {};
          innerObj[fullSubName] = subValue;
          query += this.modifyPostParam(innerObj) + '&';
        }
      }
      else if(value instanceof Object) {
        for(subName in value) {
          subValue = value[subName];
          fullSubName = name + '[' + subName + ']';
          innerObj = {};
          innerObj[fullSubName] = subValue;
          query += this.modifyPostParam(innerObj) + '&';
        }
      }
      else if(value !== undefined && value !== null)
        query += encodeURIComponent(name) + '=' + encodeURIComponent(value) + '&';
    }

    return query.length ? query.substr(0, query.length - 1) : query;
  },
  getHomepageRouter: function(){
    return this.globalData.homepageRouter;
  },
  getAppId: function(){
    return this.globalData.appId;
  },
  getDefaultPhoto: function(){
    return this.globalData.defaultPhoto;
  },
  globalData:{
    appId: 'SHq4Dzxth8',
    homepageRouter: null,
    formData: null,
    userInfo: null,
    cdnUrl: 'http://1251027630.cdn.myqcloud.com/1251027630',
    defaultPhoto: 'http://1251027630.cdn.myqcloud.com/1251027630/zhichi_frontend/static/webapp/images/default_photo.png',
    siteBaseUrl:'https://www.jisuapp.cn'
  }
})
