
var app = getApp()
var util = require('../../utils/util.js')

Page({
  data: {
    orderInfo: {},
    orderStatus: {
      '0' : '待付款',
      '1' : '待发货',
      '2' : '待收货',
      '3' : '待评价',
      '4' : '退款审核中',
      '5' : '退款中',
      '6' : '已完成',
      '7' : '已关闭'
    },
    modalHidden: true,
    modalText: '',
    addressList: [],
    selectAddressId: '',
    addressDialogHidden: true,
    isFromBack: false
  },
  onLoad: function(options){
    var orderId = options.detail;

    this.getOrderDetail(orderId);
    // this.getAddressList();
  },
  onShow: function(){
    if(this.data.isFromBack){
      this.getOrderDetail(this.data.orderInfo.order_id);
    } else {
      this.setData({
        isFromBack: true
      })
    }
  },
  getOrderDetail: function(orderId){
    var that = this;
    app.getOrderDetail({
      data: {
        order_id: orderId
      },
      success: function(res){
        var form_data = res.data[0].form_data;

        form_data.totalPay = form_data.total_price + form_data.express_fee;
        that.setData({
          orderInfo: form_data
        })
      }
    })
  },
  // getAddressList: function(){
  //   var that = this;
  //   app.sendRequest({
  //     url: '/index.php?r=AppShop/addressList',
  //     success: function(res){
  //       that.setData({
  //         addressList: res.data
  //       })
  //     }
  //   })
  // },
  cancelOrder: function(e){
    var orderId = this.data.orderInfo.order_id,
        that = this;

    app.showModal({
      content: '是否取消订单？',
      showCancel: true,
      confirmText: '是',
      cancelText: '否',
      confirm: function(){
        app.sendRequest({
          url: '/index.php?r=AppShop/cancelOrder',
          data: {
            order_id: orderId
          },
          success: function(res){
            var data = {};

            data['orderInfo.status'] = 7;
            data.modalHidden = true;
            that.setData(data);
          }
        })
      }
    })
  },
  payOrder: function(e){
// 支付
    // var id = $('.orderDetail-order-id').text().trim(),
    //     payment = $('.orderDetail-payment').find('.orderDetail-check-box.checked').attr('payment');

    // if(!id) {
    //   alertTip('order id undefined');
    //   return;
    // }
    // if(!$('.orderDetail-name').length){
    //   alertTip('请填写地址信息');
    //   return;
    // }

    // if(payment == 1){
    //   window.open('/index.php?r=AppShop/getUniPay&order_id='+id+'&payment_id=1');
    // } else {
    //   APP.turnToPage({router: 'payPage'});
    // }
  },
  applyDrawback: function(){
    var orderId = this.data.orderInfo.order_id,
        that = this;

    app.showModal({
      content: '确定要申请退款？',
      showCancel: true,
      confirmText: '确定',
      cancelText: '取消',
      confirm: function(){
        app.sendRequest({
          url: '/index.php?r=AppShop/applyRefund',
          data: {
            order_id: orderId
          },
          success: function(res){
            var data = {};

            data['orderInfo.status'] = 4;
            data.modalHidden = true;
            that.setData(data);
          }
        })
      }
    })
  },
  recevieDrawback: function(){
    var orderId = this.data.orderInfo.order_id,
        that = this;

    app.showModal({
      content: '确定已收到退款？',
      showCancel: true,
      confirmText: '确定',
      cancelText: '取消',
      confirm: function(){
        app.sendRequest({
          url: '/index.php?r=AppShop/comfirmRefund',
          data: {
            order_id: orderId
          },
          success: function(res){
            var data = {};

            data['orderInfo.status'] = 7;
            data.modalHidden = true;
            that.setData(data);
          }
        })
      }
    })
  },
  checkLogistics: function(){
    var orderId = this.data.orderInfo.order_id;
    app.turnToPage('../logisticsPage/logisticsPage?detail='+orderId);
  },
  sureReceipt: function(){
    var orderId = this.data.orderInfo.order_id,
        that = this;

    app.showModal({
      content: '确定已收到货物？',
      showCancel: true,
      confirmText: '确定',
      cancelText: '取消',
      confirm: function(){
        app.sendRequest({
          url: '/index.php?r=AppShop/comfirmOrder',
          data: {
            order_id: orderId
          },
          success: function(res){
            var data = {};

            data['orderInfo.status'] = 3;
            data.modalHidden = true;
            that.setData(data);
          }
        })
      }
    })
  },
  makeComment: function(){
    var orderId = this.data.orderInfo.order_id;
    app.turnToPage('../makeComment/makeComment?detail='+orderId);
  },
  addAddress: function(){
    app.turnToPage('../addAddress/addAddress');
  },
  selectAddress: function(e){
    var index = e.currentTarget.dataset.index,
        orderId = this.data.orderInfo.order_id,
        newAddress = this.data.addressList[index],
        that = this;

    app.sendRequest({
      url: '/index.php?r=AppShop/setAddress',
      data: {
        order_id: orderId,
        address_id: newAddress.id
      },
      success: function(res){
        that.setData({
          'orderInfo.address_info': newAddress.address_info
        });
        that.hideAddressDialog();
      }
    });
  },
  editAddress: function(e){
    var index = e.currentTarget.dataset.index,
        addressId = this.data.addressList[index].id,
        orderId = this.data.orderInfo.order_id;

    app.turnToPage('../addAddress/addAddress?id='+addressId+'&oid='+orderId);
  },
  showAddressDialog: function(e){
    var addressId = e.currentTarget.dataset.id,
        orderId = this.data.orderInfo.order_id;

    app.turnToPage('../myAddress/myAddress?id='+addressId+'&oid='+orderId);
    // this.setData({
    //   addressDialogHidden: false
    // })
  },
  hideAddressDialog: function(){
    this.setData({
      addressDialogHidden: true
    })
  },
  deleteAddress: function(e){
    var index = e.currentTarget.dataset.index,
        id = this.data.addressList[index].id,
        that = this;

    app.showModal({
      content: '确定要删除地址？',
      showCancel: true,
      confirmText: '确定',
      cancelText: '取消',
      confirm: function(){
        app.sendRequest({
          url: '/index.php?r=AppShop/delAddress',
          data: {
            address_id: id
            // ck_id: GetCookiePara()
          },
          success: function(res){
            var list = that.data.addressList,
                data = {};

            list.splice(index, 1);
            data.addressList = list;
            if(id == that.data.orderInfo.address_info.id){
              data['orderInfo.address_info'] = null;
            }
            that.setData(data);
          }
        })
      }
    })
  }
})
