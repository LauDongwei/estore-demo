var appInstance = getApp();
var WxParse = require('../../components/wxParse/wxParse.js');

var pageData    = {
  data: {"layout_vessel1":{"type":"layout-vessel","style":"height:64;background-color:rgb(253, 253, 253);background-image:;min-height:auto;margin-left:auto;","content":{"leftEles":[{"type":"picture","style":"width:1.25rem;height:1.625rem;margin-left:auto;","content":"http:\/\/img.weiye.me\/zcimgdir\/album\/file_56d68eb121a68.jpg","customFeature":{"action":"custom-link","page-link":"http:\/\/art.cfw.cn\/119410.html","custom-page-link":"http:\/\/art.cfw.cn\/119410.html"},"animations":[],"compId":"data.content.leftEles[0]","parentCompid":"layout_vessel1"},{"type":"text","style":"text-align:center;font-size:0.75rem;margin-top:0.375rem;margin-left:auto;","content":"女人","customFeature":{"action":"custom-link","page-link":"http:\/\/art.cfw.cn\/119410.html","custom-page-link":"http:\/\/art.cfw.cn\/119410.html"},"animations":[],"compId":"data.content.leftEles[1]","parentCompid":"layout_vessel1","markColor":"","mode":0}],"rightEles":[{"type":"layout-vessel","style":"height:54;min-height:auto;margin-left:auto;","content":{"leftEles":[{"type":"picture","style":"width:1.375rem;height:1.625rem;margin-top:-0.6875rem;margin-left:auto;margin-right:auto;","content":"http:\/\/img.weiye.me\/zcimgdir\/album\/file_56d69261de816.jpg","customFeature":{"action":"custom-link","page-link":"http:\/\/art.cfw.cn\/124846.html","custom-page-link":"http:\/\/art.cfw.cn\/124846.html"},"animations":[],"compId":"data.content.leftEles[0]","parentCompid":null},{"type":"text","style":"text-align:center;font-size:0.75rem;margin-top:0.375rem;margin-left:auto;","content":"男人","customFeature":{"action":"custom-link","page-link":"http:\/\/art.cfw.cn\/124846.html","custom-page-link":"http:\/\/art.cfw.cn\/124846.html"},"animations":[],"compId":"data.content.leftEles[1]","parentCompid":null,"markColor":"","mode":0}],"rightEles":[{"type":"layout-vessel","style":"height:46;margin-top:-0.25rem;margin-left:auto;","content":{"leftEles":[{"type":"picture","style":"width:1.5rem;height:1.625rem;margin-top:-1.1875rem;margin-left:auto;","content":"http:\/\/img.weiye.me\/zcimgdir\/album\/file_56d692f7cb10f.jpg","customFeature":{"action":"custom-link","page-link":"http:\/\/art.cfw.cn\/list102s-1.html","custom-page-link":"http:\/\/art.cfw.cn\/list102s-1.html"},"animations":[],"compId":"data.content.leftEles[0]","parentCompid":null},{"type":"text","style":"text-align:center;font-size:0.75rem;margin-top:0.375rem;margin-left:auto;","content":"饰品","customFeature":{"action":"custom-link","page-link":"http:\/\/art.cfw.cn\/list102s-1.html","custom-page-link":"http:\/\/art.cfw.cn\/list102s-1.html"},"animations":[],"compId":"data.content.leftEles[1]","parentCompid":null,"markColor":"","mode":0}],"rightEles":[{"type":"picture","style":"width:1.5rem;height:1.625rem;margin-top:-1.1875rem;margin-left:auto;","content":"http:\/\/img.weiye.me\/zcimgdir\/album\/file_56d6931ef37d8.jpg","customFeature":{"action":"custom-link","page-link":"http:\/\/art.cfw.cn\/list43m-0-0-1.html","custom-page-link":"http:\/\/art.cfw.cn\/list43m-0-0-1.html"},"animations":[],"compId":"data.content.rightEles[0]","parentCompid":null},{"type":"text","style":"text-align:center;font-size:0.75rem;margin-top:0.375rem;margin-left:auto;","content":"箱包","customFeature":{"action":"custom-link","page-link":"http:\/\/art.cfw.cn\/list43m-0-0-1.html","custom-page-link":"http:\/\/art.cfw.cn\/list43m-0-0-1.html"},"animations":[],"compId":"data.content.rightEles[1]","parentCompid":null,"markColor":"","mode":0}]},"customFeature":[],"animations":[],"parentCompid":null}]},"customFeature":{"cellWidth":"36"},"animations":[],"parentCompid":"layout_vessel1","cell_style_1":"width:36%;margin-left:auto;","cell_style_2":"width:64%;border-left-style:;margin-left:auto;"}]},"customFeature":{"cellWidth":"25"},"animations":[],"page_form":"","compId":"layout_vessel1","cell_style_1":"width:25%;margin-left:auto;","cell_style_2":"width:75%;border-left-style:;margin-left:auto;"},"layout_vessel2":{"type":"layout-vessel","style":"height:64;background-color:rgb(253, 253, 253);background-image:;min-height:auto;margin-left:auto;","content":{"leftEles":[{"type":"picture","style":"width:1.375rem;height:1.625rem;margin-left:auto;","content":"http:\/\/img.weiye.me\/zcimgdir\/album\/file_56d6942548a86.jpg","customFeature":{"action":"custom-link","page-link":"http:\/\/art.cfw.cn\/list45m-0-0-1.html","custom-page-link":"http:\/\/art.cfw.cn\/list45m-0-0-1.html"},"animations":[],"compId":"data.content.leftEles[0]","parentCompid":"layout_vessel2"},{"type":"text","style":"text-align:center;font-size:0.75rem;margin-top:0.375rem;margin-left:auto;","content":"配件","customFeature":{"action":"custom-link","page-link":"http:\/\/art.cfw.cn\/list45m-0-0-1.html","custom-page-link":"http:\/\/art.cfw.cn\/list45m-0-0-1.html"},"animations":[],"compId":"data.content.leftEles[1]","parentCompid":"layout_vessel2","markColor":"","mode":0}],"rightEles":[{"type":"layout-vessel","style":"height:54;min-height:auto;margin-left:auto;","content":{"leftEles":[{"type":"picture","style":"width:1.375rem;height:1.625rem;margin-top:-0.6875rem;margin-left:auto;","content":"http:\/\/img.weiye.me\/zcimgdir\/album\/file_56d69465cd212.jpg","customFeature":{"action":"custom-link","page-link":"https:\/\/dongxi.douban.com\/search?q=%E5%AE%B6%E5%B1%85","custom-page-link":"https:\/\/dongxi.douban.com\/search?q=%E5%AE%B6%E5%B1%85"},"animations":[],"compId":"data.content.leftEles[0]","parentCompid":null},{"type":"text","style":"text-align:center;font-size:0.75rem;margin-top:0.375rem;margin-left:auto;","content":"生活家居","customFeature":{"action":"custom-link","page-link":"https:\/\/dongxi.douban.com\/search?","custom-page-link":"https:\/\/dongxi.douban.com\/search?"},"animations":[],"compId":"data.content.leftEles[1]","parentCompid":null,"markColor":"","mode":0}],"rightEles":[{"type":"layout-vessel","style":"height:46;margin-top:-0.25rem;margin-left:auto;","content":{"leftEles":[{"type":"picture","style":"width:1.25rem;height:1.625rem;margin-top:-1.1875rem;margin-left:auto;","content":"http:\/\/img.weiye.me\/zcimgdir\/album\/file_56d694863ffda.jpg","customFeature":{"action":"custom-link","page-link":"https:\/\/dongxi.douban.com\/search?q=%E5%A5%BD%E5%90%83%E7%9A%84","custom-page-link":"https:\/\/dongxi.douban.com\/search?q=%E5%A5%BD%E5%90%83%E7%9A%84"},"animations":[],"compId":"data.content.leftEles[0]","parentCompid":null},{"type":"text","style":"text-align:center;font-size:0.75rem;margin-top:0.375rem;margin-left:auto;","content":"好吃的","customFeature":{"action":"custom-link","page-link":"https:\/\/dongxi.douban.com\/search?q=%E5%A5%BD%E5%90%83%E7%9A%84","custom-page-link":"https:\/\/dongxi.douban.com\/search?q=%E5%A5%BD%E5%90%83%E7%9A%84"},"animations":[],"compId":"data.content.leftEles[1]","parentCompid":null,"markColor":"","mode":0}],"rightEles":[{"type":"picture","style":"width:1.5rem;height:1.625rem;margin-top:-1.1875rem;margin-left:auto;","content":"http:\/\/img.weiye.me\/zcimgdir\/album\/file_56d69496740e1.jpg","customFeature":{"action":"custom-link","page-link":"https:\/\/dongxi.douban.com\/search?q=%E6%98%A5%E5%AD%A3%E4%B8%8A%E6%96%B0","custom-page-link":"https:\/\/dongxi.douban.com\/search?q=%E6%98%A5%E5%AD%A3%E4%B8%8A%E6%96%B0"},"animations":[],"compId":"data.content.rightEles[0]","parentCompid":null},{"type":"text","style":"text-align:center;font-size:0.75rem;margin-top:0.375rem;margin-left:auto;","content":"春季上新","customFeature":{"action":"custom-link","page-link":"https:\/\/dongxi.douban.com","custom-page-link":"https:\/\/dongxi.douban.com"},"animations":[],"compId":"data.content.rightEles[1]","parentCompid":null,"markColor":"","mode":0}]},"customFeature":[],"animations":[],"parentCompid":null}]},"customFeature":{"cellWidth":"36"},"animations":[],"parentCompid":"layout_vessel2","cell_style_1":"width:36%;margin-left:auto;","cell_style_2":"width:64%;border-left-style:;margin-left:auto;"}]},"customFeature":{"cellWidth":"25"},"animations":[],"page_form":"","compId":"layout_vessel2","cell_style_1":"width:25%;margin-left:auto;","cell_style_2":"width:75%;border-left-style:;margin-left:auto;"},"breakline3":{"type":"breakline","style":"border-color:rgb(243, 243, 243);width:18.75rem;margin-left:auto;margin-right:auto;","content":"<div><\/div>","customFeature":[],"animations":[],"page_form":"","compId":"breakline3"},"album4":{"style":"text-align:left;background-color:rgba(0, 0, 0, 0);background-image:;margin-left:auto;","ul_style":"padding-left:0.25rem;padding-top:0.25rem;margin-left:auto;","html_mode":"","li":[{"action":"inner-link","li_class":"album-pic router","pic":"http:\/\/img.weiye.me\/zcimgdir\/album\/file_5706351a336ef.jpg","title":"","router":"page10009","li_style":"width:9.625rem;margin-right:0.25rem;margin-bottom:0.25rem;margin-left:auto;","img_style":"height:9.5rem;margin-left:auto;","eventParams":"{\"inner-page-link\":\"\\\/pages\\\/page10009\\\/page10009\"}","eventHandler":"tapInnerLinkHandler"},{"action":"inner-link","li_class":"album-pic router","pic":"http:\/\/img.weiye.me\/zcimgdir\/album\/file_57062dc42022b.jpg","title":"","router":"page10009","li_style":"width:9.625rem;margin-right:0.25rem;margin-bottom:0.25rem;margin-left:auto;","img_style":"height:9.5rem;margin-left:auto;","eventParams":"{\"inner-page-link\":\"\\\/pages\\\/page10009\\\/page10009\"}","eventHandler":"tapInnerLinkHandler"}],"itemType":"album","itemParentType":null,"itemIndex":"album4","content":""},"free_vessel5":{"type":"free-vessel","style":"margin-top:-0.375rem;height:2.75rem;margin-left:auto;","content":[{"type":"text","style":"position:absolute;margin:0;left:4.4375rem;top:0.375rem;font-size:0.75rem;text-align:center;margin-left:auto;","content":"本无","customFeature":[],"animations":[],"compId":"data.content[0]","parentCompid":"free_vessel5"},{"type":"text","style":"position:absolute;margin:0;left:3.3125rem;top:1.375rem;font-size:0.75rem;text-align:center;margin-left:auto;","content":"单肩包·挎包","customFeature":[],"animations":[],"compId":"data.content[1]","parentCompid":"free_vessel5"},{"type":"text","style":"position:absolute;margin:0;left:12.9375rem;top:1.375rem;font-size:0.75rem;text-align:center;margin-left:auto;","content":"单肩包·挎包","customFeature":[],"animations":[],"compId":"data.content[2]","parentCompid":"free_vessel5"},{"type":"text","style":"position:absolute;margin:0;left:14.125rem;top:0.375rem;font-size:0.75rem;width:3rem;height:1.25rem;margin-left:auto;","content":"本无","customFeature":[],"animations":[],"compId":"data.content[3]","parentCompid":"free_vessel5"}],"customFeature":{"action":"inner-link","page-link":"page10009","inner-page-link":"page10009"},"animations":[],"page_form":"","compId":"free_vessel5","itemType":"free-vessel","itemParentType":null,"itemIndex":"free_vessel5","eventParams":"{\"inner-page-link\":\"\\\/pages\\\/page10009\\\/page10009\"}","eventHandler":"tapInnerLinkHandler"},"layout_vessel6":{"type":"layout-vessel","style":"height:32;margin-top:-0.6875rem;margin-left:auto;","content":{"leftEles":[{"type":"count-ele","style":"font-size:0.75rem;margin-left:3.6875rem;margin-right:0;margin-top:-0.0625rem;margin-bottom:;","content":"喜欢","customFeature":{"size":"22px"},"animations":[],"compId":"data.content.leftEles[0]","parentCompid":"layout_vessel6","icon":"love-icon","icon_size":"22px","ifAutoCount":null,"objrel":"SHq4Dzxth8"}],"rightEles":[{"type":"count-ele","style":"font-size:0.75rem;margin-left:3.25rem;margin-right:0;margin-top:-0.0625rem;margin-bottom:;","content":"喜欢","customFeature":{"size":"22px"},"animations":[],"compId":"data.content.rightEles[0]","parentCompid":"layout_vessel6","icon":"love-icon","icon_size":"22px","ifAutoCount":null,"objrel":"SHq4Dzxth8"}]},"customFeature":[],"animations":[],"page_form":"","compId":"layout_vessel6"},"breakline7":{"type":"breakline","style":"width:18.75rem;margin-left:auto;margin-right:auto;border-color:rgb(243, 243, 243);","content":"<div><\/div>","customFeature":[],"animations":[],"page_form":"","compId":"breakline7"},"goods_list8":{"type":"goods-list","style":"background-color:rgb(243, 243, 243);background-image:;margin-top:-0.3125rem;height:auto;margin-left:auto;","content":"","customFeature":{"source":"83","lineBackgroundColor":"rgb(255, 255, 255)","lineBackgroundImage":"","height":"267px","margin":1,"lineHeight":80,"vesselAutoheight":1,"imgWidth":80,"imgHeight":80},"animations":[],"page_form":"","compId":"goods_list8","list_style":"margin-bottom:0.0625rem;background-color:rgb(255, 255, 255);height:5rem;margin-left:auto;","img_style":"width:5rem;height:5rem;margin-left:auto;","title_width":{"width":"230px"},"param":"{\"id\":null,\"form\":null,\"page\":1,\"app_id\":\"SHq4Dzxth8\",\"is_count\":0}"},"goods_list9":{"type":"goods-list","style":"background-color:rgb(243, 243, 243);background-image:;height:auto;margin-left:auto;","content":"","customFeature":{"source":"73","height":"244px","lineBackgroundColor":"rgb(255, 255, 255)","lineBackgroundImage":"","vesselAutoheight":1,"imgWidth":80,"imgHeight":82,"lineHeight":82},"animations":[],"page_form":"","compId":"goods_list9","list_style":"background-color:rgb(255, 255, 255);height:5.125rem;margin-left:auto;","img_style":"width:5rem;height:5.125rem;margin-left:auto;","title_width":{"width":"230px"},"param":"{\"id\":null,\"form\":null,\"page\":1,\"app_id\":\"SHq4Dzxth8\",\"is_count\":0}"},"text10":{"type":"text","style":"text-align:center;background-color:rgba(0, 0, 0, 0);background-image:;color:rgb(102, 102, 102);margin-top:0.25rem;margin-left:auto;","content":"这里你可以继续添加商品什么的！！！","customFeature":[],"animations":[],"page_form":"","compId":"text10"}},

    page_form: 'none',
      list_compids_params: [],
      goods_compids_params: [{"compid":"goods_list8","param":{"id":null,"form":null,"page":1,"app_id":"SHq4Dzxth8","is_count":0}},{"compid":"goods_list9","param":{"id":null,"form":null,"page":1,"app_id":"SHq4Dzxth8","is_count":0}}],
      relobj_auto: [{"obj_rel":"SHq4Dzxth8","auto_add_count":null,"compid":"data.content.leftEles[0]","parentcompid":"layout_vessel6","has_counted":0},{"obj_rel":"SHq4Dzxth8","auto_add_count":null,"compid":"data.content.rightEles[0]","parentcompid":"layout_vessel6","has_counted":0}],
      bbsCompIds: [],
      dynamicVesselComps: [],
      tapInnerLinkHandler: function(event) {
    console.log('handling tap inner link event=====================');
    console.log(event);
    if (event.currentTarget.dataset.eventParams) {
        var url = JSON.parse(event.currentTarget.dataset.eventParams)['inner-page-link'];
        if (url) {
            appInstance.turnToPage(url);
        }
    }
},
    onLoad: function (e) {
    var _this = this;
    var newdata = {};

    newdata['userInfo'] = appInstance.globalData.userInfo;
    this.setData(newdata);

    if (!!e.detail && !!this.page_form) {
      var dataid = parseInt(e.detail);
      var param = {};

      param.data_id = dataid;
      param.form = _this.page_form;
      appInstance.sendRequest({
        url: '/index.php?r=AppData/getFormData',
        data: param,
        success: function (res) {
          if (res.status == 0) {
            newdata = {};
            newdata['detail_data'] = res.data[0].form_data;

            for (let i in newdata['detail_data']) {
              if (i == 'category') {
                continue;
              }

              let description = newdata['detail_data'][i];

              if (!description) {
                continue;
              }

              let matchResult = description && description.match(/<p>[\s\S]*?<\/p>/g);
              if (matchResult) {
                newdata['detail_data'][i] = WxParse('html', newdata['detail_data'][i]);
              }
            }
            _this.setData(newdata);

            if (!!_this.dynamicVesselComps) { // 处理动态容器请求
              for (let i in _this.dynamicVesselComps) {
                let vessel_param = _this.dynamicVesselComps[i].param;
                let compid = _this.dynamicVesselComps[i].compid;
                if (!!newdata.detail_data[vessel_param.param_segment]) {
                  vessel_param.idx = vessel_param.search_segment;
                  vessel_param.idx_value = newdata.detail_data[vessel_param.param_segment];
                  appInstance.sendRequest({
                    url: '/index.php?r=AppData/getFormDataList&idx_arr[idx]=' + vessel_param.idx + "&idx_arr[idx_value]=" + vessel_param.idx_value,
                    data: {
                      app_id: vessel_param.app_id,
                      form: vessel_param.form,
                      page: 1
                    },
                    success: function(res) {
                      if (res.status == 0) {
                        let newDynamicData = {};
                        newDynamicData['dynamic_vessel_data_' + compid] = res.data[0];
                        _this.setData(newDynamicData);
                      } else {
                        // TODO 提示框
                      }
                    },
                    fail: function() {
                      console.log("[fail info]dynamic-vessel data request  failed");
                    }
                  });
                }
              }
            }
          } else {
            // TODO 提示框
          }
        },
        fail: function () {
          // TODO 错误
        },
      })
    }

    if (!!this.list_compids_params) {
      for (let i in this.list_compids_params) {
        let compid = this.list_compids_params[i].compid;
        let param = this.list_compids_params[i].param;
        let url = '/index.php?r=AppData/getFormDataList';
        if (!!param.idx_arr) {
          let idx = param.idx_arr.idx;
          let idx_value = param.idx_arr.idx_value;
          delete(param.idx_arr);
          url = '/index.php?r=AppData/getFormDataList&idx_arr[idx]=' + idx + "&idx_arr[idx_value]=" + idx_value;
        }
        appInstance.sendRequest({
          url: url,
          data: param,
          success: function (res) {
            if (!!param.idx_arr) {
              param.idx_arr = {
                idx: idx,
                idx_value: idx_value
              };
            }
            if (res.status == 0) {
              newdata = {};

              for (let j in res.data) {
                for (let k in res.data[j].form_data) {
                  if (k == 'category') {
                    continue;
                  }

                  let description = res.data[j].form_data[k];

                  if (!description) {
                    continue;
                  }

                  let matchResult = description && description.match(/<p>[\s\S]*?<\/p>/g);
                  if (matchResult) {
                    res.data[j].form_data[k] = WxParse('html', res.data[j].form_data[k]);
                  }
                }
              }

              newdata[compid + '.list_data'] = res.data;
              newdata[compid + '.is_more'] = res.is_more;
              newdata[compid + '.curpage'] = 1;

              _this.setData(newdata);
            } else {
              // TODO 提示框
            }
          },
          fail: function () {
            // TODO 错误
          },
        });
      }
    }

    if (!!this.goods_compids_params) {
      for (let i in this.goods_compids_params) {
        let compid = this.goods_compids_params[i].compid;
        let param = this.goods_compids_params[i].param;

        appInstance.sendRequest({
          url: '/index.php?r=AppShop/GetGoodsList',
          data: param,
          success: function (res) {
            if (res.status == 0) {
              newdata = {};
              newdata[compid + '.goods_data'] = res.data;
              newdata[compid + '.is_more'] = res.is_more;
              newdata[compid + '.curpage'] = 1;

              _this.setData(newdata);
            } else {
              // TODO 提示框
            }
          },
          fail: function () {
            // TODO 错误
          },
        });
      }
    }

    if (!!this.relobj_auto) {
      for (let i in this.relobj_auto) {
        let objrel = this.relobj_auto[i].obj_rel;
        let AutoAddCount = this.relobj_auto[i].auto_add_count;
        let compid = this.relobj_auto[i].compid;
        let hasCounted = this.relobj_auto[i].has_counted;   // 默认是 0，没有计算过
        let parentcompid = this.relobj_auto[i].parentcompid;

        if (parentcompid != '' && parentcompid != null) {
          if (compid.search('data.') !== -1) {
            compid = compid.substr(5);
          }
          compid = parentcompid + '.' + compid;
        }

        appInstance.sendRequest({
          url: '/index.php?r=AppData/getCount',
          data: {
            obj_rel: objrel
          },
          success: function (res) {
            if (res.status == 0) {
              if (AutoAddCount == 1) {
                if (hasCounted == 0) {
                  appInstance.sendRequest({
                    url: '/index.php?r=AppData/addCount',
                    data: {
                      obj_rel: objrel
                    },
                    success: function (newres) {
                      if (newres.status == 0) {
                        newdata = {};
                        newdata[compid + '.count_data.count_num'] = parseInt(newres.data.count_num);
                        newdata[compid + '.count_data.has_count'] = parseInt(newres.data.has_count);
                        _this.setData(newdata);
                      }
                    },
                    fail: function () {
                      // TODO 提示框
                    }
                  });
                }
              } else {
                newdata = {};
                newdata[compid + '.count_data.count_num'] = parseInt(res.data.count_num);
                newdata[compid + '.count_data.has_count'] = parseInt(res.data.has_count);
                _this.setData(newdata);
              }
            } else {
              // TODO 提示框
            }
          },
          fail: function () {
            // TODO 错误
          },
        });
      }
    }
  },

  pageScrollFunc: function (e) {
    console.log("到底了~~");
    let compid = e.target.dataset.compid;
    let param = e.target.dataset.param;
    let curpage = parseInt(e.target.dataset.curpage) + 1;

    param = JSON.parse(param);
    param.page = curpage;

    var newdata = {};
    var _this = this;
    if (!!this.data[compid].is_more) {
      appInstance.sendRequest({
        url: '/index.php?r=AppData/getFormDataList',
        data: param,
        success: function (res) {
          if (res != undefined && res.status == 0) {
            newdata = {};

            for (let j in res.data) {
              for (let k in res.data[j].form_data[k]) {
                if (k == 'category') {
                  continue;
                }

                let description = res.data[j].form_data[k];

                if (!description) {
                  continue;
                }

                let matchResult = description && description.match(/<p>[\s\S]*?<\/p>/g);
                if (matchResult) {
                  res.data[j].form_data[k] = WxParse('html', res.data[j].form_data[k]);
                }
              }
            }

            newdata[compid + '.list_data'] = _this.data[compid].list_data.concat(res.data);
            newdata[compid + '.is_more'] = res.is_more;
            newdata[compid + '.curpage'] = res.current_page;

            _this.setData(newdata);
          } else {
            // TODO 提示框
          }
        },
        fail: function () {
          // TODO 错误
        },
      })
    }
  },
  goodsScrollFunc: function (e) {
    let compid = e.target.dataset.compid;
    let param = e.target.dataset.param;
    let curpage = parseInt(e.target.dataset.curpage) + 1;

    param = JSON.parse(param);
    param.page = curpage;

    var newdata = {};
    var _this = this;
    if (!!this.data[compid].is_more) {
      appInstance.sendRequest({
        url: '/index.php?r=AppShop/GetGoodsList',
        data: param,
        success: function (res) {
          if (res.status == 0) {
            newdata = {};
            newdata[compid + '.goods_data'] = _this.data[compid].goods_data.concat(res.data);
            newdata[compid + '.is_more'] = res.is_more;
            newdata[compid + '.curpage'] = res.current_page;

            _this.setData(newdata);
          } else {
            // TODO 提示框
          }
        },
        fail: function () {
          // TODO 错误
        },
      })
    }
  },
  changeCount: function (e) {
    let counted = e.currentTarget.dataset.counted;
    let compid = e.currentTarget.dataset.compid;
    let objrel = e.currentTarget.dataset.objrel;
    let form = e.currentTarget.dataset.form;
    let dataIndex = e.currentTarget.dataset.index;
    let parentcompid = e.currentTarget.dataset.parentcompid;

    var newdata = {};
    var _this = this;

    if (!!form) {        // 这是一个 form
      if (counted == 1) {  // 计算过了，del
        appInstance.sendRequest({
          url: '/index.php?r=AppData/delCount',
          data: {
            obj_rel: objrel
          },
          success: function (res) {
            if (res.status == 0) {
              newdata = {};
              newdata[parentcompid + '.list_data[' + dataIndex + '].count_num'] = parseInt(_this.data[parentcompid].list_data[dataIndex].count_num) - 1;
              newdata[parentcompid + '.list_data[' + dataIndex + '].has_count'] = 0;
              _this.setData(newdata);
            }
          },
          fail: function () {
            // TODO 提示框
          }
        })

      } else {
        appInstance.sendRequest({
          url: '/index.php?r=AppData/addCount',
          data: {
            obj_rel: objrel
          },
          success: function (res) {
            if (res.status == 0) {
              newdata = {};
              newdata[parentcompid + '.list_data[' + dataIndex + '].count_num'] = parseInt(res.data.count_num);
              newdata[parentcompid + '.list_data[' + dataIndex + '].has_count'] = parseInt(res.data.has_count);
              _this.setData(newdata);
            }
          },
          fail: function () {
            // TODO 提示框
          }
        })

      }
    } else {
      if (parentcompid != '' && parentcompid != null) {
        if (compid.search('data.') !== -1) {
          compid = compid.substr(5);
        }
        compid = parentcompid + '.' + compid;
      }

      if (counted == 1) {  // 计算过了，del
        appInstance.sendRequest({
          url: '/index.php?r=AppData/delCount',
          data: {
            obj_rel: objrel
          },
          success: function (res) {
            if (res.status == 0) {
              newdata = {};
              newdata[compid + '.count_data.count_num'] = parseInt(res.data.count_num);
              newdata[compid + '.count_data.has_count'] = parseInt(res.data.has_count);
              _this.setData(newdata);
            }
          },
          fail: function () {
            // TODO 提示框
          }
        })
      } else {             // 没计算过，add
        appInstance.sendRequest({
          url: '/index.php?r=AppData/addCount',
          data: {
            obj_rel: objrel
          },
          success: function (res) {
            if (res.status == 0) {
              newdata = {};
              newdata[compid + '.count_data.count_num'] = parseInt(res.data.count_num);
              newdata[compid + '.count_data.has_count'] = parseInt(res.data.has_count);
              _this.setData(newdata);
            }
          },
          fail: function () {
            // TODO 提示框
          }
        })
      }
    }
  },
  inputChange: function (e) {
    let datakey = e.currentTarget.dataset.datakey;
    let value = e.detail.value;

    var newdata = {};

    newdata[datakey] = value;
    this.setData(newdata);
  },
  bindDateChange: function(e) {
    let datakey      = e.currentTarget.dataset.datakey;
    let parentcompid = e.currentTarget.dataset.parentcompid;
    let compid       = e.currentTarget.dataset.compid;
    let value        = e.detail.value;
    let newdata      = {};

    let datakeyArr = datakey.split('.');
    let obj = this.data;
    for (let i = 0; i < datakeyArr.length; i++) {
      if (obj[datakeyArr[i]] == undefined) {
        obj = undefined;
        break;
      } else {
        obj = obj[datakeyArr[i]];
      }
    }

    if (!!obj) {
      let date = obj.substr(0, 10);
      let time = obj.substr(11);

      if (obj.length == 16) {
        newdata[datakey] = value + ' ' + time;
      } else if (obj.length == 10) {  // 只设置了 date
        newdata[datakey] = value;
      } else if (obj.length == 5) {   // 只设置了 time
        newdata[datakey] = value + ' ' + obj;
      } else if (obj.length == 0) {
        newdata[datakey] = value;
      }
    } else {
      newdata[datakey] = value;
    }

    if (compid.substr(0, 4) == 'data') {
      compid = parentcompid + compid.substr(4);
    }
    newdata[compid + '.date'] = value;
    this.setData(newdata);
  },
  bindTimeChange: function(e) {
    let datakey      = e.currentTarget.dataset.datakey;
    let parentcompid = e.currentTarget.dataset.parentcompid;
    let compid       = e.currentTarget.dataset.compid;
    let value        = e.detail.value;
    let newdata      = {};

    let datakeyArr = datakey.split('.');
    let obj = this.data;
    for (let i = 0; i < datakeyArr.length; i++) {
      if (obj[datakeyArr[i]] == undefined) {
        obj = undefined;
        break;
      } else {
        obj = obj[datakeyArr[i]];
      }
    }

    if (!!obj) {
      let date = obj.substr(0, 10);
      let time = obj.substr(11);

      if (obj.length == 16) {
        newdata[datakey] = date + ' ' + value;
      } else if (obj.length == 10) {  // 只设置了 date
        newdata[datakey] = obj + ' ' + value;
      } else if (obj.length == 5) {   // 只设置了 time
        newdata[datakey] = value;
      } else if (obj.length == 0) {
        newdata[datakey] = value;
      }
    } else {
      newdata[datakey] = value;
    }

    if (compid.substr(0, 4) == 'data') {
      compid = parentcompid + compid.substr(4);
    }
    newdata[compid + '.time'] = value;
    this.setData(newdata);
  },
  submitForm: function (e) {
    let compid = e.currentTarget.dataset.compid;
    let form = e.currentTarget.dataset.form;

    let form_data = this.data[compid].form_data;
    let field_info = this.data[compid].field_info;

    var newdata;

    var _this = this;

    if (!!form_data) {
      for (let i in field_info) {
        let field = field_info[i].field;
        if (!form_data[field] && field_info[i].required == 1) { // 提示错误
          // 提示错误
          console.log('error');
          return;
        }
      }
    }

    appInstance.sendRequest({
      url: '/index.php?r=AppData/addData',
      data: {
        form: form,
        form_data: form_data
      },
      header: {'Content-Type': 'application/x-www-form-urlencoded;'},
      method: 'POST',
      success: function (res) {
        if (res.status == 0) {
          newdata = _this.data[compid];
          newdata.form_data = {};
          _this.setData(newdata);
        }
      },
      fail: function () {
        // TODO 提示框
      }
    })

  },
  udpateVideoSrc: function (e) {
    let compid = e.currentTarget.dataset.compid;

    var _this = this;
    var newdata = {};

    wx.chooseVideo({
      sourceType: ['album', 'camera'],
      maxDuration: 60,
      camera: ['front', 'back'],
      success: function (res) {
        newdata = {};
        newdata[compid + '.src'] = res.tempFilePaths[0];
        _this.setData(newdata);
        // TODO 保存视频地址
      }
    })
  },
  tapMapDetail: function (event) { // 进入地图详情页
    console.log('handling tap map detail event====');
    appInstance.turnToPage("../mapDetail/mapDetail?eventParams=" + event.currentTarget.dataset.eventParams);
  },
  uploadFormImg: function (e) {
    let compid = e.currentTarget.dataset.compid;
    let parentcompid = e.currentTarget.dataset.parentcompid;
    let datakey = e.currentTarget.dataset.datakey;

    var newdata = {};
    var _this = this;

    appInstance.chooseImage(function (res) {
      let img_src = res[0];
      wx.saveFile({
        tempFilePath: img_src,
        success: function (saveRes) {
          newdata = {};
          newdata[datakey] = saveRes.savedFilePath;
          newdata[parentcompid] = _this.data[parentcompid];
          newdata[parentcompid].display_upload = false;
          newdata[parentcompid].image_src = saveRes.savedFilePath;
          _this.setData(newdata);
        }
      })
    });
  },
  listVesselTurnToPage: function (e) {
    let data_id = e.currentTarget.dataset.dataid;
    let router = e.currentTarget.dataset.router;
    let page_form = this.page_form;

    if (page_form != '') {
      appInstance.turnToPage('../' + router + '/' + router + '?detail=' + data_id);
    }
  },
  UserCenterTurnToPage: function (e) {
    let router = e.currentTarget.dataset.router;
    appInstance.turnToPage('../' + router + '/' + router);
  },
  turnToGoodsDetail: function (e) {
    let id = e.currentTarget.dataset.id;
    appInstance.turnToPage('../goodsDetail/goodsDetail?detail=' + id);
  }
};
Page(pageData);